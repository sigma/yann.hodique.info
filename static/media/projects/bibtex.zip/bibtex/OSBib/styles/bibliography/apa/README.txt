BIBLIOGRAPHIC STYLE:
American Psychological Association (APA)

INSTALLATION:
Place this folder into /styles/bibliography/

COMPILER:
Mark Grimshaw (2005)