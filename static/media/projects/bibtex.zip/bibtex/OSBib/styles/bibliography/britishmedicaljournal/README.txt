WIKINDX

BIBLIOGRAPHIC STYLE:
British Medical Journal (BMJ)

INSTALLATION:
Place this folder into /styles/bibliography/

COMPILER:
Mark Grimshaw (2005)