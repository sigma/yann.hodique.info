WIKINDX

BIBLIOGRAPHIC STYLE:
Institute of Electrical and Electronic Engineers (IEEE)

INSTALLATION:
Place this folder into /styles/bibliography/

COMPILER:
Mark Grimshaw (2005)