BIBLIOGRAPHIC STYLE:
Turabian

INSTALLATION:
Place this folder into /styles/bibliography/

COMPILER:
Mark Grimshaw (2005)